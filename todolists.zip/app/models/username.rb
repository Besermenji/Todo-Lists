class Username < ActiveRecord::Base
end
